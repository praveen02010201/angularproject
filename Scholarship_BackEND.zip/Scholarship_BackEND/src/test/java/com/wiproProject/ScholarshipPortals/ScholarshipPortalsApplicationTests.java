package com.wiproProject.ScholarshipPortals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScholarshipPortalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
