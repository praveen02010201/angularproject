package com.wiproProject.AirlineReservations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineReservationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
